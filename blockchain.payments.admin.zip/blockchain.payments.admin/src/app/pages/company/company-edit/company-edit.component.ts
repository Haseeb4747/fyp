import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RestApiService } from '../../../services/api/rest-api.service';
import { HelperService } from '../../../services/helper/helper.service';
import { AuthService } from '../../../services/auth/auth.service';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CompanyListComponent } from '../company-list/company-list.component';
@Component({
  selector: 'app-company-edit',
  templateUrl: './company-edit.component.html',
  styleUrls: ['./company-edit.component.scss']
})
export class CompanyEditComponent implements OnInit {

  submitted = false;
  isDataLoaded = false;
  isRequested = true;


  userId;
  email;
  userForm: FormGroup;

  services = [];

  status = [];
  cities = [];
  industryTypes = [];

  isPasswordValidated = true;

  @Input() user;

  constructor(private fb: FormBuilder, private api: RestApiService, private helper: HelperService,
    private auth: AuthService, private router: Router, private activeModal: NgbActiveModal) {
    if (this.auth.user.email) {
      this.email = this.auth.user.email;
    } else {
      this.router.navigateByUrl('auth/login');
    }
  }

  ngOnInit() {

    this.submitted = false;
    this.isDataLoaded = true;

    this.status = [
      { name:"pending"},
      { name:"approved"},
      { name:"blocked"}
    ]

    this.cities = [
      { name:"Karachi"},
      { name:"Lahore"},
      { name:"Faisalabad"},
      { name:"Rawalpindi"},
      { name:"Gujranwala"},
      { name:"Peshawar"},
      { name:"Multan"},
      { name:"Hyderabad"},
      { name:"Islamabad"},
      { name:"Quetta"},
      { name:"Bahawalpur"},
      { name:"Sargodha"},
      { name:"Sialkot"},
      { name:"Sukkur"},
      { name:"Jhang"},
      { name:"Larkana"},
      { name:"Gujrat"},
      { name:"Mardan"},
      { name:"Other"}
    ]


    this.industryTypes = [
      { name:"Manufacturing"},
      { name:"Information-Technology"},
      { name:"Insurance-Takaful"},
      { name:"Banking-Financial-Services"},
      { name:"Real-Estate-Property"},
      { name:"Telecommunication-ISP"},
      { name:"Textiles-Garments"},
      { name:"Healthcare-Medical"},
      { name:"Food-Beverages"},
      { name:"Travel-Tourism"},
      { name:"Accounting-Taxation"},
      { name:"Education"},
      { name:"Others"}
    ]



    this.userForm = this.fb.group({
      state: [this.user.state, Validators.required],
      name: [this.user.name, Validators.required],
      email: [this.user.email, Validators.required],
      contact: [this.user.contact, Validators.required],
      address: [this.user.address, Validators.required],
      city: [this.user.city, Validators.required],
      industryType: [this.user.industryType, Validators.required],
      newPassword: [''],
      confirmPassword: ['']
    });

  }

  get f() { return this.userForm.controls; }


  closeMe() {
    this.activeModal.close();
  }

  onSubmit() {
    this.submitted = true;
    // console.log('Form Values', this.userForm.value);

    if (this.userForm.valid) {

      this._passwordCheck();

      if (this.isPasswordValidated) {

        this.isRequested = false;
        const name = this.user.name;
        // const username = this.userForm.controls['name'].value;
        this._sendUpdateRequest(this.userForm.value, name);

      }

    }
  }

  _sendUpdateRequest(data, name) {
    console.log("Req",data)

    this.api.patch('company/update_company/', data.email, data).then((response: any) => {

      this.isRequested = true;
      this.helper.successBigToast('Success ', 'Successfully Updated!');
      // this.helper.successToast('Success', 'Successfully updated: ' + name + '\'s Account');
      
      setTimeout(() => 
      {
        window.location.reload();
      },
      1000);

    }, (error: any) => {

      this.isRequested = true;

      if (error.error.Message) {
        if (error.error.Message === 'Already Exists') {
          // tslint:disable-next-line: max-line-length
          this.helper.failureBigToast('Failed!', '"' + name + '" is already assigned to another user, kindly user different username for login.');
          return;
        }
      }

      this.helper.failureBigToast('Failed!', 'Invalid data, kindly check updated data.');
    });

  }

  _passwordCheck() {
    const password = this.userForm.controls['newPassword'].value;
    const confirmPassword = this.userForm.controls['confirmPassword'].value;

    if (password !== '') {
      if (password !== confirmPassword) {
        this.userForm.controls['confirmPassword'].setErrors({ NoPassswordMatch: true });
        this.isPasswordValidated = false;
      }
    }

  }


}
