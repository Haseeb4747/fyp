import { Component, OnInit } from "@angular/core";
import { RestApiService } from "../../../services/api/rest-api.service";
import { Router } from "@angular/router";
import { HelperService } from "../../../services/helper/helper.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FaqEditComponent } from "../faq-edit/faq-edit.component";
import { FaqAddComponent } from "../faq-add/faq-add.component";

@Component({
  selector: "app-faq-list",
  templateUrl: "./faq-list.component.html",
  styleUrls: ["./faq-list.component.scss"]
})
export class FaqListComponent implements OnInit {
  isDataLoaded = false;
  userId;
  faqs = [];

  dtOptions: DataTables.Settings = {};

  constructor(
    private api: RestApiService,
    private router: Router,
    private helper: HelperService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    console.log("ngOnInit called");
    this.getFaqs();
  }

  getFaqs() {
    this.api
      .get("faqs")
      .then((response: any) => {
        this.faqs = response;
        console.log(this.faqs);

        this.dtOptions = {
          data: this.faqs,
          columns: [
            {
              title: "Title",
              data: "title"
            },
            {
              title: "Description",
              data: "description"
            }
          ],
          rowCallback: (row: Node, data: any[] | Object, index: number) => {
            const self = this;
            // tslint:disable-next-line: deprecation
            $("td", row).unbind("click");
            // tslint:disable-next-line: deprecation
            $("td", row).bind("click", () => {
              self.selectedFaq(data);
            });
            return row;
          }
        };

        this.isDataLoaded = true;
      })
      .catch(err => console.log("Error", err));
  }

  selectedFaq(faq) {
    this._openEditModal(faq);
  }

  _openEditModal(faq) {
    const modalRef = this.modalService.open(FaqEditComponent);
    modalRef.componentInstance.faq = faq;
  }

  openAddModal() {
    const modalRef = this.modalService.open(FaqAddComponent);

    modalRef.result.then(
      () => {
        this.ngOnInit();
      },
      () => {
        this.ngOnInit();
      }
    );
  }
}
