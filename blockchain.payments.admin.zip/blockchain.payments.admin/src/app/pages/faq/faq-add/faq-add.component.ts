import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { RestApiService } from "../../../services/api/rest-api.service";
import { HelperService } from "../../../services/helper/helper.service";
import { AuthService } from "../../../services/auth/auth.service";
import { Router } from "@angular/router";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-faq-add",
  templateUrl: "./faq-add.component.html",
  styleUrls: ["./faq-add.component.scss"]
})
export class FaqAddComponent implements OnInit {
  submitted = false;
  isDataLoaded = false;
  isRequested = true;

  userId;
  email;
  faqForm: FormGroup;

  isPasswordValidated = true;

  constructor(
    private fb: FormBuilder,
    private api: RestApiService,
    private helper: HelperService,
    private auth: AuthService,
    private router: Router,
    private activeModal: NgbActiveModal
  ) {
    if (this.auth.user.email) {
      this.email = this.auth.user.email;
    } else {
      this.router.navigateByUrl("auth/login");
    }
  }

  ngOnInit() {
    this.submitted = false;
    this.isDataLoaded = false;

    this.faqForm = this.fb.group({
      title: ["", Validators.required],
      description: ["", Validators.required]
    });
  }

  get f() {
    return this.faqForm.controls;
  }

  closeMe() {
    this.activeModal.close();
  }

  onSubmit() {
    this.submitted = true;
    // console.log("Form Values", this.faqForm.value);

    if (this.faqForm.valid) {
      this._sendAddRequest(this.faqForm.value);
    }
  }

  _sendAddRequest(data) {
    console.log("Req", data);

    this.api.post("addFaq", data).then(
      (response: any) => {
        this.isRequested = true;
        this.helper.successBigToast("Success", "Successfully Added FAQ");

        setTimeout(() => {
          window.location.reload();
        }, 1000);
      },
      (error: any) => {
        this.isRequested = true;

        if (error.error.Message) {
          if (error.error.Message === "Already Exists") {
            // tslint:disable-next-line: max-line-length
            this.helper.failureBigToast(
              "Failed!",
              '"' +
                name +
                '" is already assigned to another user, kindly user different username for login.'
            );
            return;
          }
        }

        this.helper.failureBigToast(
          "Failed!",
          "Invalid data, kindly check updated data."
        );
      }
    );
  }
}
