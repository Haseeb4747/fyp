import { Component, OnInit } from "@angular/core";
import { NgModel } from "@angular/forms";
import { AuthService } from "../../../services/auth/auth.service";
import { Router } from "@angular/router";
import { HelperService } from "../../../services/helper/helper.service";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit {
  isSubmitted = false;
  spinnerText = "";

  constructor(
    private auth: AuthService,
    private router: Router,
    private helper: HelperService,
    private spinnerService: NgxSpinnerService
  ) {
    if (this.auth.isLoggedIn) {
      this.router.navigateByUrl("dashboard/admin");
    }
  }
  ngOnInit() {}

  onSubmit(form: NgModel) {
    // console.log(form.value);

    if (form.valid) {
      this.isSubmitted = true;

      this.spinnerService.show();
      this.spinnerText = "Logging in Admin...";

      this.auth.login(form.value).then((data: any) => {
        this.isSubmitted = false;

        // console.log(data);

        if (data === "open") {
          this.spinnerService.hide();

          this.helper.successToast(
            "Welcome " + "Admin",
            "Successfully Authenticated!"
          );

          console.log("role", this.auth.user);

          if (this.auth.user.email != null) {
            console.log("dashboard/admin");
            this.router.navigateByUrl("dashboard/admin");
          } else {
            this.helper.infoToast("Invalid User", "Contact Administrator!");
          }
        } else if (data === "locked") {
          this.spinnerService.hide();
          this.helper.failureBigToast(
            "Failed!",
            "Your account is locked, kindly contact administrator."
          );
        } else {
          this.spinnerService.hide();
          this.helper.failureBigToast(
            "Failed!",
            "Incorrect username or password."
          );
          // this.helper.failureToast('Incorrect username or password', 'Authentication Failed!');
        }
      });
    }
  }
}
