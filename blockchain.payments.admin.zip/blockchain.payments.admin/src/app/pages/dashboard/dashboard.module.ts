import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { DataTablesModule } from 'angular-datatables';

import { ChartistModule } from 'ng-chartist';
import { CountUpModule } from 'countup.js-angular2';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';




@NgModule({
  declarations: [DashboardAdminComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    CountUpModule,
    NgbModule,
    ChartistModule,
    CommonModule,
    DashboardRoutingModule
  ],
  entryComponents: []
})
export class DashboardModule { }
