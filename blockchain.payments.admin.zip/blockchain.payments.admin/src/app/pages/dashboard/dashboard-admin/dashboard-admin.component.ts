import { Component, OnInit } from '@angular/core';
import { HelperService } from '../../../services/helper/helper.service';
import * as Chartist from 'chartist';
import { ChartEvent, ChartType } from 'ng-chartist';
import { RestApiService } from '../../../services/api/rest-api.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


export interface Chart {
  type: ChartType;
  data: Chartist.IChartistData;
  options?: any;
  responsiveOptions?: any;
  events?: ChartEvent;
}

@Component({
  selector: 'app-dashboard-admin',
  templateUrl: './dashboard-admin.component.html',
  styleUrls: ['./dashboard-admin.component.scss']
})
export class DashboardAdminComponent implements OnInit {

  lastRefreshed;


  total_registered_users=0;
  total_registered_companies=0;
  total_transactions;
  total_approved_transactions;

  isDataLoaded = false;
  userId;
  companies = [];


  dtOptions: DataTables.Settings = {};

  constructor(private api: RestApiService, private helper: HelperService, private modalService: NgbModal) { }

  ngOnInit() {
    this.lastRefreshed = this.helper.getCurrentTime();
    
    this.totalRegisteredUsersAndCompanies();
    this.totalTransactions();
    this.totalApprovedTransactions();
    
  }



  totalRegisteredUsersAndCompanies() {

    this.api.get('users').then((data: any) => {
      // console.log('Data', data);
      for(var i=0; i<data.length; i++)
      {
        if(data[i].userrole=="1")
        {
          this.total_registered_users++
        }
        else if(data[i].userrole=="2")
        {
          this.total_registered_companies++
        }
      }
      
      console.log("total_registered_users: "+this.total_registered_users);
      console.log("total_registered_users: "+this.total_registered_companies);
    }).catch(err => console.log('Error', err));

  }

  totalTransactions() {

      this.api.get('transactions').then((data: any) => {
      this.total_transactions=data.length;
      console.log("total_transactions: "+this.total_transactions);
    }).catch(err => console.log('Error', err));

  }

  totalApprovedTransactions() {

    this.api.get('transactionsProof').then((data: any) => {
      // console.log('Data', data);
      this.total_approved_transactions=data.length;
      console.log("total_approved_transactions: "+this.total_approved_transactions);
    }).catch(err => console.log('Error', err));
  }


}
