import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../../../../services/api/rest-api.service';
import { HelperService } from '../../../../services/helper/helper.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-transaction-report',
  templateUrl: './transaction-report.component.html',
  styleUrls: ['./transaction-report.component.scss']
})
export class TransactionReport implements OnInit {

  transactionDate = [];
  transactionAmount = [];
  Linechart = [];
  transaction = [];
  constructor(private api: RestApiService, private helper: HelperService) { }

  ngOnInit() {

    this.getTransactions()
  }

  getTransactions() {
    this.api.get('transactions').then((response: any) => {
      this.transaction = response;

      for (var i = 0; i < response.length; i++) {
        this.transactionAmount.push(response[i].amount);

        var formattedDatetime = getDateTimeFromTimestamp(response[i].uploadDate);

        this.transactionDate.push(formattedDatetime);
      }


      function getDateTimeFromTimestamp(unixTimeStamp) {
        var date = new Date(unixTimeStamp);
        return ('0' + date.getDate()).slice(-2) + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + date.getFullYear() + ' ' + ('0' + date.getHours()).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2);
      }



      this.Linechart = new Chart('canvas', {
        type: 'line',
        data: {
          labels: this.transactionDate,
          datasets: [
            {
              data: this.transactionAmount,
              borderColor: '#3cb371',
              backgroundColor: "#0000FF",
            }
          ]
        },
        options: {
          legend: {
            display: false
          },
          scales: {
            xAxes: [{
              display: true
            }],
            yAxes: [{
              display: true
            }],
          }
        }
      });





    }).catch(err => console.log('Error', err));


  }




}
