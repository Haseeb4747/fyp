import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { TransactionReport } from './admin/transaction-report/transaction-report.component';


@NgModule({
  // tslint:disable-next-line: max-line-length
  declarations: [TransactionReport],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    ReportsRoutingModule
  ]
})
export class ReportsModule { }
