import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../../../services/api/rest-api.service';
import { Router } from '@angular/router';
import { HelperService } from '../../../services/helper/helper.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserEditComponent } from '../user-edit/user-edit.component';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  isDataLoaded = false;
  userId;
  users = [];

  

  dtOptions: DataTables.Settings = {};


  constructor(private api: RestApiService, private router: Router, private helper: HelperService, private modalService: NgbModal) { }

  ngOnInit(): void {
    console.log("ngOnInit called")
    this.getUsers();
  }


  getUsers() {
    this.api.get('users').then((response: any) => {
      // this.users = response;
      var a = 0;
      for(var i=0; i<response.length;i++){
        if(response[i].userrole=="1"){
          this.users[a]=response[i];
          a++;
        }
      }
      console.log(this.users)


      this.dtOptions = {
        data: this.users,
        columns: [{
          title: 'Full Name',
          data: 'fullname',
          render: function (data, type, row) {
            return '<span title="' + row.useremail + '">' + data + '</span>';
          }
        },
        {
          title: 'Contact',
          data: 'usercontact'
        },
        {
          title: 'Email',
          data: 'useremail'
        },
        {
          title: 'Amount',
          data: 'amount'
        },

      ],
        // rowCallback: (row: Node, data: any[] | Object, index: number) => {
        //   const self = this;
        //   $('td', row).unbind('click');
        //   $('td', row).bind('click', () => {
        //     self.selectedUser(data);
        //   });
        //   return row;
        // }
      };

      this.isDataLoaded = true;
    }).catch(err => console.log('Error', err));
  }



  selectedUser(user) {
    this._openEditModal(user);
  }

  _openEditModal(user) {
    const modalRef = this.modalService.open(UserEditComponent);
    modalRef.componentInstance.user = user;

    // modalRef.result.then(() => { window.location.reload() });


    // modalRef.result.then(() => { window.location.reload() }, () => { window.location.reload()});
    // modalRef.result.then(() => { this.ngOnInit(); }, () => { this.ngOnInit(); });
  }
}
