import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../../../services/api/rest-api.service';
import { Router } from '@angular/router';
import { HelperService } from '../../../services/helper/helper.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.scss']
})
export class TransactionListComponent implements OnInit {

  isDataLoaded = false;
  userId;
  transaction = [];

  

  dtOptions: DataTables.Settings = {};


  constructor(private api: RestApiService, private router: Router, private helper: HelperService, private modalService: NgbModal) { }

  ngOnInit(): void {
    console.log("ngOnInit called")
    this.getUsers();
  }


  getUsers() {
    this.api.get('transactions').then((response: any) => {
      this.transaction = response;

      console.log(this.transaction)


      this.dtOptions = {
        data: this.transaction,
        columns: [
        {
          title: 'Sender Name',
          data: 'sendername'
        },
        {
          title: 'Sender Email',
          data: 'senderemail'
        },
        {
          title: 'Receiver Name',
          data: 'receivername'
        },
        {
          title: 'Receiver Email',
          data: 'receiveremail'
        },
        {
          title: 'Amount',
          data: 'amount'
        },
      ],
        rowCallback: (row: Node, data: any[] | Object, index: number) => {
          const self = this;
          // tslint:disable-next-line: deprecation
          $('td', row).unbind('click');
          // tslint:disable-next-line: deprecation
          $('td', row).bind('click', () => {
            // self.selectedUser(data);
          });
          return row;
        }
      };

      this.isDataLoaded = true;
    }).catch(err => console.log('Error', err));
  }




}
