export const EncryptionPassword = 'digitalDairy';
