export const EncryptionPassword = 'blockchain';
