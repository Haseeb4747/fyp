import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-width',
  templateUrl: './full-width.component.html',
  styleUrls: ['./full-width.component.scss']
})
export class FullWidthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
