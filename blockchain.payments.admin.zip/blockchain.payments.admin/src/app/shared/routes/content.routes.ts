import { Routes, RouterModule } from '@angular/router';

export const content: Routes = [
  {
    path: 'dashboard',
    loadChildren: './pages/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'company',
    loadChildren: './pages/company/company.module#CompanyModule'
  },
  {
    path: 'user',
    loadChildren: './pages/user/user.module#UserModule'
  },
  {
    path: 'transaction',
    loadChildren: './pages/transaction/transaction.module#TransactionModule'
  },
  {
    path: 'faq',
    loadChildren: './pages/faq/faq.module#FaqModule'
  },
  {
    path: 'report',
    loadChildren: './pages/report/reports.module#ReportsModule'
  },

];
