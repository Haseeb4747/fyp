// Menu
export interface Menu {
  path?: string;
  title?: string;
  icon?: string;
  type?: string;
  headTitle?: string;
  badgeType?: string;
  badgeValue?: string;
  children?: Menu[];
}

export const MenuItemsAdmin: Menu[] = [
  {
    path: "/dashboard/admin",
    title: "Dashboard",
    icon: "icon-desktop",
    type: "link"
  },
  {
    path: "/company/list",
    title: "Companies",
    icon: "icon-home",
    type: "link"
  },
  {
    path: "/user/list",
    title: "Users",
    icon: "icon-user",
    type: "link"
  },
  {
    path: "/transaction/list",
    title: "Transactions",
    icon: "icon-folder",
    type: "link"
  },
  {
    path: "/faq/list",
    title: "F.A.Q",
    icon: "icon-envelope",
    type: "link"
  },

  {
    headTitle: "Reports"
  },
  {
    path: "/report/transaction",
    title: "Transactions Report",
    icon: "icon-bar-chart",
    type: "link"
  }
  // {
  //   path: '/report/rating_wise', title: 'Rating Report', icon: 'icon-star', type: 'link'
  // },
];

export const MenuItemsCashier: Menu[] = [
  // {
  //   path: '/dashboard/cashier', title: 'Dashboard', icon: 'icon-desktop', type: 'link'
  // },
  // {
  //   path: '/currencies/list', title: 'Rates', icon: 'icon-bar-chart', type: 'link'
  // },
  // {
  //   headTitle: 'Currency'
  // },
  // {
  //   path: '/transactions/bill', title: 'Bill Transaction', icon: 'icon-direction-alt', type: 'link'
  // },
  // {
  //   path: '/voucher/generate', title: 'Transfer Voucher', icon: 'icon-agenda', type: 'link'
  // },
  // {
  //   headTitle: 'Expenses'
  // },
  // {
  //   path: '/voucher/generate', title: 'Double Entry', icon: 'icon-agenda', type: 'link'
  // },
  // {
  //   path: '/voucher/generate', title: 'Journal Voucher', icon: 'icon-agenda', type: 'link'
  // }
];
