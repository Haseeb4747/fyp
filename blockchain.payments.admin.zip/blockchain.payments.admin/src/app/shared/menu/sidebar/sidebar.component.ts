import { Component, OnInit } from '@angular/core';
import { MenuItemsAdmin, MenuItemsCashier, Menu } from './sidebar-items';
import { Router, ActivatedRoute } from "@angular/router";
import * as $ from 'jquery';
import { AuthService } from '../../../services/auth/auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  public menuItems: Menu[];

  constructor(private router: Router,
    private route: ActivatedRoute,
    public auth: AuthService) {
  }

  ngOnInit() {
    $.getScript('./assets/js/sidebar-menu.js');

    let email = this.auth.user.email;

    if (email != null) {
      this.menuItems = MenuItemsAdmin.filter(menuItem => menuItem);
    }

    // if (role === 1) {
    //   this.menuItems = MenuItemsCashier.filter(menuItem => menuItem);
    // }

  }

}
