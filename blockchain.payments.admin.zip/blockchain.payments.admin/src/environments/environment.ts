export const environment = {
  production: false,
  // apiURL: 'http://localhost:3300',
  apiURL: 'https://blockchain-payments.herokuapp.com',
  reportURL: ''
};
