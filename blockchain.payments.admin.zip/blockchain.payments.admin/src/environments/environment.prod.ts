export const environment = {
  production: true,
  // apiURL: 'http://localhost:3300/',
  apiURL: 'http://hr-agency-suite.herokuapp.com',
  reportURL: ''
};

