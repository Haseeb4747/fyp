export const environment = {
  production: true,
  // apiURL: 'http://localhost:3300/',
  apiURL: 'https://blockchain-payments.herokuapp.com',
  reportURL: ''
};

