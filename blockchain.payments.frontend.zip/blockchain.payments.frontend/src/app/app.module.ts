import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import * as $ from 'jquery';





import { environment } from '../environments/environment';
import { HomeComponent } from './pages/home/home.component';
import { HeaderComponent } from './pages/components/header/header.component';
import { FooterComponent } from './pages/components/footer/footer.component';
import { SliderComponent } from './pages/components/slider/slider.component';
import { LoginComponent } from './pages/login/login.component';
import { ForgetComponent } from './pages/forget/forget.component';
import { RegisterAsComponent } from './pages/register-as/register-as.component';
import { RegisterUserComponent } from './pages/register-user/register-user.component';
import { RegisterCompanyComponent } from './pages/register-company/register-company.component';
import { UserProfileComponent } from './pages/user-profile/user-profile.component';
import { EditUserProfileComponent } from './pages/edit-user-profile/edit-user-profile.component';
import { CompanyProfileComponent } from './pages/company-profile/company-profile.component';
import { EditCompanyProfileComponent } from './pages/edit-company-profile/edit-company-profile.component';
import { JobManagementComponent } from './pages/job-management/job-management.component';
import { PrivacyPolicyComponent } from './pages/privacy-policy/privacy-policy.component';
import { TermsAndConditionComponent } from './pages/terms-and-condition/terms-and-condition.component';
import { PayNowComponent } from './pages/pay-now/pay-now.component';
import { JobSearchAllComponent } from './pages/job-search-all/job-search-all.component';
import { TransactionsComponent } from './pages/transactions/transactions.component';



import { ToastrModule } from 'ngx-toastr';


import { FormsModule } from '@angular/forms';

import { NgxSpinnerModule } from 'ngx-spinner';

import { LocationStrategy, HashLocationStrategy } from '@angular/common';

import { AgmCoreModule } from '@agm/core';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { AgmDirectionModule } from 'agm-direction';
import { NgxFileDropModule } from 'ngx-file-drop';

import {NgxPaginationModule} from 'ngx-pagination';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { StarRatingModule } from 'angular-star-rating';
import { AboutComponent } from './pages/about/about.component';
import { FaqComponent } from './pages/faq/faq.component';
import { ContactUsComponent } from './pages/contact-us/contact-us.component';
import { ServicesComponent } from './pages/services/services.component';
import { ContactsComponent } from './pages/contacts/contacts.component';

import { RestApiService } from './services/api/rest-api.service';
import { HelperService } from './services/helper/helper.service';
import { AuthService } from './services/auth/auth.service';

import { AsyncPipe } from '@angular/common';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { PushNotificationsModule } from 'ng-push';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    SliderComponent,
    LoginComponent,
    ForgetComponent,
    RegisterAsComponent,
    RegisterUserComponent,
    RegisterCompanyComponent,
    UserProfileComponent,
    EditUserProfileComponent,
    CompanyProfileComponent,
    EditCompanyProfileComponent,
    JobManagementComponent,
    PrivacyPolicyComponent,
    TermsAndConditionComponent,
    PayNowComponent,
    JobSearchAllComponent,
    AboutComponent,
    FaqComponent,
    ContactUsComponent,
    ServicesComponent,
    ContactsComponent,
    TransactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    FormsModule,
    NgxSpinnerModule,
    NgxFileDropModule,
    PushNotificationsModule,
    HttpClientModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyA_QD2_rlwEFGhCK0oj2n6cixsvX0D3zgk',
      libraries: ['places']
    }),
    AgmDirectionModule,
    GooglePlaceModule,
    NgxPaginationModule,
    MDBBootstrapModule.forRoot(),
    StarRatingModule.forRoot()
  ],
  providers: [ RestApiService, HelperService, AuthService, AsyncPipe,{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
