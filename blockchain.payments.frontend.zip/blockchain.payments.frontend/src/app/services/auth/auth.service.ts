import { Injectable } from '@angular/core';
import { RestApiService } from '../api/rest-api.service';
import { Router } from '@angular/router';
import { StorageService } from '../storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isLoggedIn = false;
  user = undefined;



  constructor(private api: RestApiService, private router: Router, private storage: StorageService) {
 
  }

  login(userDeatils) {
    return new Promise((resolve, reject) => {
      this.api.post('login', userDeatils).then((data: any) => {
        // console.log('UserData', data);

        if (!data.Locked) {
          this.user = data;
         
          this.saveLocalTokens(data._id, data.fullname, data.useremail, data.userrole) 

          resolve('open');

        } else {
          resolve('locked');
        }


      }, () => {
        resolve(false);
      });
    });
  }


  saveLocalTokens(id, fullname, useremail, userrole) {
    let data = {
      id: id,
      fullname: fullname,
      useremail: useremail,
      userrole:userrole
    };
    localStorage.setItem("blockchain", JSON.stringify(data));
  }

  getLocalTokens() {
    return JSON.parse(localStorage.getItem("blockchain"));
  }

  clearLocalTokens() {
    return localStorage.removeItem("blockchain");
  }


  logout() {
    // Reset:
    this.isLoggedIn = false;
    this.user = undefined;
    this.storage.removeUserDetails();
    this.clearLocalTokens();
    // Redirect:
    this.router.navigate(['/auth/login']);
  }


}
