import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';

@Component({
  selector: 'app-register-employee',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
 
  useremail : any;
  user_profile : any;
  spinnerText = '';
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private route: Router) {
   }

  ngOnInit() {
    this._getUserData();
  }


  _getUserData() {

      this.spinner.show();
      this.spinnerText = 'Fetching your Profile.. Please wait';
      this.useremail =JSON.parse(localStorage.getItem('blockchain')).useremail;
      console.log(this.useremail)
      this.api.get('userprofile/'+ this.useremail).then((response: any) => {
      this.user_profile = response[0];
        console.log(this.user_profile);
      this.spinner.hide();
     
  
      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong while fetching your profile.");
      });
    }

    editEmployeeData(){
      this.route.navigate(['/edit_user_profile']);
    }


}
