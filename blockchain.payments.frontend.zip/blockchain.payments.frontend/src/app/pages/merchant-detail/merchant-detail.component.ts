import { Component, OnInit, AfterViewInit, ViewChild, ElementRef  } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { Address } from "ngx-google-places-autocomplete/objects/address";
import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router, ActivatedRoute  } from '@angular/router';

@Component({
  selector: 'app-merchant-detail',
  templateUrl: './merchant-detail.component.html',
  styleUrls: ['./merchant-detail.component.css']
})
export class MerchantDetailComponent implements OnInit {

;
  merchantEmail;
  useremail : any;
  company_profile : any;
  merchant_data : any;
  dataExist;
  spinnerText = '';
  dataLoaded = false;
  lat;
  lng;
  title;

  labelOptions = {
    color: 'black',
    fontFamily: 'arial',
    fontSize: '15px',
    fontWeight: 'bold',
    text: ""
}

  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private router: ActivatedRoute,
    private route: Router) {
      this.merchantEmail = this.router.snapshot.paramMap.get("merchantEmail");
      console.log("merchantEmail "+this.merchantEmail)
   }

  ngOnInit() {
    this._getMerchantData();
  }


    _getMerchantData() {

      this.spinner.show();
      this.spinnerText = 'Fetching your Merchant Data.. Please wait';
      this.api.get('merchantdetail/'+ this.merchantEmail).then((response: any) => {
        console.log(response);
        this.dataLoaded = true   
      if(response.length>0){
        this.merchant_data = response[0];
        this.dataExist = true
 
        this.lat = Number(this.merchant_data.merchantlat);
        this.lng = Number(this.merchant_data.merchantlon);
        this.title = this.merchant_data.merchantname;
        this.labelOptions.text = this.merchant_data.merchantname;
      }
      else{
        this.merchant_data = "nil"
        this.dataExist = false
      }
      this.spinner.hide();
      }, () => {
        this.spinner.hide();
      });
    }


}
