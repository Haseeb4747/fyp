import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';

@Component({
  selector: 'app-job-management',
  templateUrl: './job-management.component.html',
  styleUrls: ['./job-management.component.css']
})
export class JobManagementComponent implements OnInit {
 
  email : any;
  jobPosts : any;
  spinnerText = '';
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private route: Router) {
   }

  ngOnInit() {
    this._getJobPostData();
  }


  _getJobPostData() {

      this.spinner.show();
      this.spinnerText = 'Fetching your job Posts.. Please wait';
      this.email =JSON.parse(localStorage.getItem('hr-agency')).email;
      this.api.get('jobpost/search/jobPostByCompanyEmail/'+ this.email).then((response: any) => {
      this.jobPosts = response;
        console.log(this.jobPosts);
      this.spinner.hide();
     
  
      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong while fetching your profile.");
      });
    }

    postNewJob(){
      this.route.navigate(['/add_job_post']);
    }

    viewJobDetailData(jobPostId){
     
      this.route.navigate(['/job_post_detail', jobPostId]);
    }


}
