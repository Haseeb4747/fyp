import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router, ActivatedRoute  } from '@angular/router';

@Component({
  selector: 'app-pay-now',
  templateUrl: './pay-now.component.html',
  styleUrls: ['./pay-now.component.css']
})
export class PayNowComponent implements OnInit {
 
  userEmail;
  email : any;
  userProfile : any;
  spinnerText = '';
  sname: any;
  semail: any;
  rname: any;
  remail: any;
  pay_now = {
    amount: ''
  };
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private router: ActivatedRoute,
    private route: Router) {
      this.userEmail = this.router.snapshot.paramMap.get("userEmail");
      console.log("userEmail "+this.userEmail)
   }

  ngOnInit() {
    this._getUserData();
  }


  _getUserData() {

      this.spinner.show();
      this.spinnerText = 'Fetching User Profile.. Please wait';
      this.api.get('userprofile/'+ this.userEmail).then((response: any) => {
      this.userProfile = response[0];
      this.spinner.hide();
      console.log(this.userProfile)
      if(this.userProfile!=null){
        this.rname= this.userProfile.fullname;
        this.remail= this.userProfile.useremail;
      }

  
      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong while fetching user profile.");
      });
    }


    payNow(){

      if(this.pay_now.amount === '') {
        this.toastrService.error("Kindly Enter Valid Amount");
        return false;
      }
      console.log("amount: "+this.pay_now.amount)
      this.spinner.show();
      this.spinnerText = 'Transferring amount.. Please wait';
    
        this.sname = JSON.parse(localStorage.getItem('blockchain')).fullname;
        this.semail = JSON.parse(localStorage.getItem('blockchain')).useremail;

    
        let data = {
          sendername: this.sname,
          senderemail: this.semail,
          receivername: this.rname,
          receiveremail: this.remail,
          amount: this.pay_now.amount
        }
    
        console.log(data)
    
        this.api.post('addTransaction', data).then((response: any) => {
      
                   if(response.status==true){
                     this.toastrService.success("Amount transferred Successfully");
                     this.spinner.hide();
                     this.route.navigate(['/transactions']);
                   }
                   else if(response.status==false){
                     this.toastrService.error('Error: '+response.message);
                     this.spinner.hide();
                   }
         
         
                   }, () => {
                     this.toastrService.success("Failed!', 'Something went wrong, try again later.");
                     this.spinner.hide();
                   });

    }

}
