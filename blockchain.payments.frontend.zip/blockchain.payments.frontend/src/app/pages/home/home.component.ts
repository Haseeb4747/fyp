import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  search_data = {
    title: ''
  };
  blockChain : any;

  constructor(
    private route: Router,
    private api: RestApiService,
    private toastrService: ToastrService
  ) { }

  ngOnInit() {
    this._getBlockChain();
    setTimeout(() => {
      $(document).ready(function () {
        $('.tp-banner').show().revolution({
          sliderType: "standard",
          sliderLayout: "fullwidth",
          dottedOverlay: "none",
          delay: 6000,
          navigation: {
            keyboardNavigation: "off",
            keyboard_direction: "horizontal",
            mouseScrollNavigation: "off",
            mouseScrollReverse: "default",
            onHoverStop: "off",
            touch: {
              touchenabled: "on",
              swipe_threshold: 75,
              swipe_min_touches: 1,
              swipe_direction: "horizontal",
              drag_block_vertical: false
            },
            arrows: {
              style: "uranus",
              enable: true,
              hide_onleave: true
            }
          },
          responsiveLevels: [1920, 1200, 992, 768],
          visibilityLevels: [1920, 1200, 992, 768],
          gridwidth: [1920, 1200, 992, 768],
          gridheight: [778, 486, 402, 300],
          lazyType: "single",
          shadow: 0,
          spinner: "off",
          stopLoop: "on",
          stopAfterLoops: 0,
          shuffle: "off",
          autoHeight: "off",
          fullScreenAutoWidth: "off",
          fullScreenAlignForce: "off",
          disableProgressBar: "on",
          hideThumbsOnMobile: "off",
          hideSliderAtLimit: 0,
          hideCaptionAtLimit: 0,
          hideAllCaptionAtLilmit: 0,
          debugMode: false
        });
      });
    }, 2000);

  }

  _getBlockChain(){

    this.api.get('transactionsProof').then((response: any) => {
    this.blockChain = response;
    console.log(this.blockChain)
    
    
    }, 
    () => {
      this.toastrService.success("Failed!', 'Something went wrong while fetching your profile.");
    });
  }



}
