import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Observable } from 'rxjs';
import { Router } from '@angular/router';

import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {

  search_data = {
    title: ''
  };

  spinnerText = '';
  users : any;
  userContacts : any;
  uname: any;
  email: any;

  constructor(    
    private toastrService: ToastrService,
    private helper: HelperService,
    private spinner: NgxSpinnerService,
    private api: RestApiService,
    private route: Router

  ) { }

  ngOnInit() {
    this._getUserContactsData() 
  }

  search(){

    if(this.search_data.title === '') {
      this.toastrService.error("Kindly Enter Valid Email");
      return false;
    }
    console.log("Job Search Title: "+this.search_data.title)
    this._getUsersData(this.search_data.title)
    // this.route.navigate(['/job_search_title', this.search_data.title]);
  }

  _getUsersData(searchTitle) {

    this.spinner.show();
    this.spinnerText = 'Fetching contacts.. Please wait';

    this.api.get('userSearchByNameEmail/'+ searchTitle).then((response: any) => {
    this.users = response;
    this.spinner.hide();

    console.log(this.users.length)
    if(this.users.length<1){
      this.toastrService.success('with that name or email', 'No Contacts Found!');
    }   

    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while searching for contacts");
    });
  }


  addUserContact(userName,userEmail){

    console.log(userName+" "+userEmail )

    this.uname = JSON.parse(localStorage.getItem('blockchain')).fullname;
    this.email = JSON.parse(localStorage.getItem('blockchain')).useremail;

    console.log(JSON.parse(localStorage.getItem('blockchain')).fullname)

    let data = {
      name: this.uname,
      email: this.email,
      contactname: userName,
      contactemail: userEmail
    }

    console.log(data)

    this.api.post('addUserContact', data).then((response: any) => {
  
               if(response.status==true){
                 this.toastrService.success("Contact Added Successfully");
                 this._getUserContactsData()
               }
               else if(response.status==false){
                 this.toastrService.error('Error: '+response.message);
               }
     
     
               }, () => {
                 this.toastrService.success("Failed!', 'Something went wrong, try again later.");
               });

  }

  _getUserContactsData() {


    this.api.get('userContacts/'+ JSON.parse(localStorage.getItem('blockchain')).useremail).then((response: any) => {
    this.userContacts = response;
    console.log(response)

    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while searching for contacts");
    });
  }

  payNow(userEmail){
     
      this.route.navigate(['/paynow', userEmail]);
    
  }

}
