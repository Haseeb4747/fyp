import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMerchantProfileComponent } from './add-merchant-profile.component';

describe('RegisterEmployeeComponent', () => {
  let component: AddMerchantProfileComponent;
  let fixture: ComponentFixture<AddMerchantProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddMerchantProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMerchantProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
