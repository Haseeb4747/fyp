import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';
@Component({
  selector: 'app-add-merchant-profile',
  templateUrl: './add-merchant-profile.component.html',
  styleUrls: ['./add-merchant-profile.component.css']
})
export class AddMerchantProfileComponent implements OnInit {

  user_data = {
    merchantname: '',
    merchantemail: '',
    merchantservice: '',
    merchantAddress: '',
    merchantlat: '',
    merchantlon: ''
  };


  downloadURL: Observable<string>;
  uploadState: Observable<string>;
  uploadProgress: Observable<number>;
  tests: Observable<any[]>;
  uploadedImage : any;
  userData : any;
  spinnerText = '';
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private route: Router) {
   }

  ngOnInit() {
    this.user_data.merchantemail =JSON.parse(localStorage.getItem('blockchain')).useremail;
  }

  registerMerchant(){
    if(this.user_data.merchantname === '') {
      this.toastrService.error("Merchant Name is required");
      return false;
    }

    if(this.user_data.merchantservice === '') {
      this.toastrService.error("Merchant Service is required");
      return false;
    }

    if(this.user_data.merchantAddress === '') {
      this.toastrService.error("Merchant Address is required");
      return false;
    }

    if(this.user_data.merchantlat === '') {
      this.toastrService.error("Merchant Latitude is required");
      return false;
    }

    if(this.user_data.merchantlon === '') {
      this.toastrService.error("Merchant Longitude is required");
      return false;
    }


   
    let data = {
      merchantname: this.user_data.merchantname,
      merchantemail: this.user_data.merchantemail,
      merchantservice : this.user_data.merchantservice,
      merchantAddress : this.user_data.merchantAddress,
      merchantlat : this.user_data.merchantlat,
      merchantlon : this.user_data.merchantlon,
    }

      this._sendSaveRequest(data);
    } 

    _sendSaveRequest(data) {

      console.log(data)
      this.spinner.show();
      this.spinnerText = 'Adding Merchant Details... Please wait';
      
      this.api.post('addMerchant', data).then((response: any) => {
       
      this.spinner.hide();
      this.toastrService.success("Merchant Added Successfully");
  
      setTimeout(() => {
        this.route.navigate(['/company_profile']);
      }, 2500);

      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong, try again later.");
      });
    }


}
