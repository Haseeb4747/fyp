import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMerchantProfileComponent } from './edit-merchant-profile.component';

describe('EditMerchantProfileComponent', () => {
  let component: EditMerchantProfileComponent;
  let fixture: ComponentFixture<EditMerchantProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMerchantProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMerchantProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
