import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-user-profile',
  templateUrl: './edit-user-profile.component.html',
  styleUrls: ['./edit-user-profile.component.css']
})
export class EditUserProfileComponent implements OnInit {
  user_data = {
    useremail: '',
    fullname: '',
    usercontact: '',
    newpassword: '',
  };

  downloadURL: Observable<string>;
  uploadState: Observable<string>;
  uploadProgress: Observable<number>;
  tests: Observable<any[]>;
  uploadedImage : any;
  userData : any;
  useremail : any;
  spinnerText = '';
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private route: Router) {
   }

  ngOnInit() {
    this._getUserData();
  }


  _getUserData() {

    this.spinner.show();
    this.spinnerText = 'Fetching your Profile.. Please wait';
    this.useremail =JSON.parse(localStorage.getItem('blockchain')).useremail;
    this.api.get('userprofile/'+ this.useremail).then((response: any) => {
    this.user_data = response[0];
      console.log(this.user_data);
    this.spinner.hide();
   
    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while fetching your profile.");
    });
  }

  editUser(){
    if(this.user_data.fullname === '') {
      this.toastrService.error("Full Name is required");
      return false;
    }


    if(this.user_data.usercontact === '') {
      this.toastrService.error("Contact is required");
      return false;
    }
   

    
   
      let data = {
        useremail:this.user_data.useremail,
        fullname : this.user_data.fullname,
        usercontact : this.user_data.usercontact,
        userpassword : this.user_data.newpassword,
      }
      this._sendSaveRequest(data);
    } 

    _sendSaveRequest(data) {

      this.spinner.show();
      this.spinnerText = 'Editing Profile.. Please wait';
      
      this.api.post('updateUser', data).then((response: any) => {
       
      this.spinner.hide();
      this.toastrService.success("Edited Successfully");
  
      setTimeout(() => {
        this.route.navigate(['/company_profile']);
      }, 2500);

      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong, try again later.");
      });
    }


}
