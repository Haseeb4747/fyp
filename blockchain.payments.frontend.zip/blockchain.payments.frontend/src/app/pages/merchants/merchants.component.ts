import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Router } from '@angular/router';

import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-merchants',
  templateUrl: './merchants.component.html',
  styleUrls: ['./merchants.component.css']
})
export class MerchantsComponent implements OnInit {



  spinnerText = '';
  users : any;
  merchantList : any;
  uname: any;
  email: any;

  constructor(    
    private toastrService: ToastrService,
    private helper: HelperService,
    private spinner: NgxSpinnerService,
    private api: RestApiService,
    private route: Router

  ) { }

  ngOnInit() {
    this._getMerchantsData() 
  }




  _getMerchantsData() {


    this.api.get('merchants').then((response: any) => {
    this.merchantList = response;
    console.log(response)

    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while searching for contacts");
    });
  }

  detail(merchantemail){
     
      this.route.navigate(['/merchant_detail', merchantemail]);
    
  }


}
