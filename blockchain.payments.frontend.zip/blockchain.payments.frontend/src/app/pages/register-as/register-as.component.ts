import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-register-as',
  templateUrl: './register-as.component.html',
  styleUrls: ['./register-as.component.css']
})
export class RegisterAsComponent implements OnInit {
  
  constructor(
    private router: Router,
    private spinnerService: NgxSpinnerService,
    private toastrService: ToastrService
  ) {}

  ngOnInit() {}
 
}

