import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { AuthService } from '../../services/auth/auth.service';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';
@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {
  user_data = {
    email: ''
  };
  spinnerText = '';
  showPanel = false;
  role = 3;
  constructor(
    private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    private route: Router
  ) {}

  ngOnInit() {
    
  }

  forgetPassword(){
    if(this.user_data.email === '') {
      this.toastrService.error("Email is required");
      return false;
    }
    else{
      var data = {
        email : this.user_data.email
      }
      this._sendSaveRequest(data);
    }

  }


  _sendSaveRequest(data) {

    this.spinner.show();
    this.spinnerText = 'Please wait ... ';
    console.log("11")
    this.api.post('resetPassword', data).then((response: any) => {
     
    this.spinner.hide();

    if(response.status){
      setTimeout(() => {
        this.route.navigate(['/login']);
      }, 2500);
      this.toastrService.success(response.message);
    }
    else{
      this.toastrService.error(response.message);
    }

    }, () => {
      this.spinner.hide();
      this.toastrService.error('Failed!', 'This Email does not exist');
    });
  }
 
 
}

