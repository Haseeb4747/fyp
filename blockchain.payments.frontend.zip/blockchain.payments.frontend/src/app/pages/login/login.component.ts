import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { AuthService } from '../../services/auth/auth.service';

import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login_data = {
    email: '',
    password: ''
  };
  spinnerText = '';
  showPanel = false;
  role = 3;
  constructor(
    private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    private route: Router
  ) {}

  ngOnInit() {}

  login() {
    this.spinner.show();
    this.spinnerText = 'Logging in..';
   
    this.auth.login(this.login_data).then((data: any) => {
   
      if (data === 'open') {
        this.spinner.hide();
        console.log(this.auth.user);
        
        console.log('role', this.auth.user.userrole);

        if (this.auth.user.userrole === "1") {
          this.route.navigateByUrl('/user_profile');
          this.toastrService.success('Welcome ' + this.auth.user.fullname, ' Successfully Authenticated!');
        } else if (this.auth.user.userrole === "2") {
          this.route.navigateByUrl('/company_profile');
          this.toastrService.success('Welcome ' + this.auth.user.fullname, ' Successfully Authenticated!');
        } 
        else if (this.auth.user.status=== false) {
          this.toastrService.error(this.auth.user.message);
        } 
        else {

          this.toastrService.error('Invalid User', 'Contact Administrator!');
          
        }

      } else if (data === 'locked') {
        this.spinner.hide();
        this.toastrService.error('Failed!', ' Your account is locked, kindly contact administrator.');
      } else {
        this.spinner.hide();
        this.toastrService.error( 'Failed! Incorrect username or password.','Login');
       
      
      }

    

    });
  }


 register() {
   this.route.navigate(['/register_as']);
 }
 
 
}

