import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Observable } from 'rxjs';
import { Router } from '@angular/router';

import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {


  spinnerText = '';
  allFaq : any;

  constructor(    
    private toastrService: ToastrService,
    private helper: HelperService,
    private spinner: NgxSpinnerService,
    private api: RestApiService,
    private route: Router

  ) { }

  ngOnInit() {
    this._getFaqData() 
  }

  _getFaqData() {

    this.api.get('faqs').then((response: any) => {
    this.allFaq = response;
    console.log(response)

    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while fetching FAQ's");
    });
  }



}
