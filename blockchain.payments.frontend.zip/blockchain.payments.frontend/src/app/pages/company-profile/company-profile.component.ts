import { Component, OnInit, AfterViewInit, ViewChild, ElementRef  } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { Address } from "ngx-google-places-autocomplete/objects/address";
import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.component.html',
  styleUrls: ['./company-profile.component.css']
})
export class CompanyProfileComponent implements OnInit {


  // smarkers;
  useremail : any;
  company_profile : any;
  merchant_data : any;
  dataExist;
  spinnerText = '';
  dataLoaded = false;
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private route: Router) {
   }

  ngOnInit() {
    this._getCompanyData();
    this._getMerchantData();
  }


  _getCompanyData() {

      this.spinner.show();
      this.spinnerText = 'Fetching your Profile.. Please wait';
      this.useremail =JSON.parse(localStorage.getItem('blockchain')).useremail;
      this.api.get('userprofile/'+ this.useremail).then((response: any) => {
      this.company_profile = response[0];
        console.log(this.company_profile);
      this.spinner.hide();
     
  
      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong while fetching your profile.");
      });
    }

    _getMerchantData() {


      this.useremail =JSON.parse(localStorage.getItem('blockchain')).useremail;
      this.api.get('merchantdetail/'+ this.useremail).then((response: any) => {
        console.log(response);
        this.dataLoaded = true   
      if(response.length>0){
        this.merchant_data = response[0];
        this.dataExist = true
      }
      else{
        this.merchant_data = "nil"
        this.dataExist = false
      }
  
      }, () => {
      });
    }

    addMerchantData(){
      this.route.navigate(['/add_merchant_profile']);
    }
    editMerchantData(){
      this.route.navigate(['/edit_merchant_profile']);
    }

    editEmployeeData(){
      this.route.navigate(['/edit_company_profile']);
    }
}
