import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';
import { Address } from "ngx-google-places-autocomplete/objects/address";
import { Observable } from 'rxjs';

import { NgxSpinnerService } from "ngx-spinner";

import { Router } from '@angular/router';

@Component({
  selector: 'app-company-profile',
  templateUrl: './company-profile.component.html',
  styleUrls: ['./company-profile.component.css']
})
export class CompanyProfileComponent implements OnInit {


  useremail : any;
  company_profile : any;
  spinnerText = '';
  constructor(private toastrService: ToastrService,
    private helper: HelperService,
    private api: RestApiService,
    private spinner: NgxSpinnerService,
    private route: Router) {
   }

  ngOnInit() {
    this._getCompanyData();
  }


  _getCompanyData() {

      this.spinner.show();
      this.spinnerText = 'Fetching your Profile.. Please wait';
      this.useremail =JSON.parse(localStorage.getItem('blockchain')).useremail;
      this.api.get('userprofile/'+ this.useremail).then((response: any) => {
      this.company_profile = response[0];
        console.log(this.company_profile);
      this.spinner.hide();
     
  
      }, () => {
        this.toastrService.success("Failed!', 'Something went wrong while fetching your profile.");
      });
    }

    editEmployeeData(){
      this.route.navigate(['/edit_company_profile']);
    }


}
