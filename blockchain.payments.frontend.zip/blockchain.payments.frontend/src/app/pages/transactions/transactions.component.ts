import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../../services/api/rest-api.service';
import { HelperService } from '../../services/helper/helper.service';

import { Observable } from 'rxjs';
import { Router } from '@angular/router';

import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {


  spinnerText = '';
  users : any;
  receiveTransactions : any;
  sendTransactions : any;

  constructor(    
    private toastrService: ToastrService,
    private helper: HelperService,
    private spinner: NgxSpinnerService,
    private api: RestApiService,
    private route: Router

  ) { }

  ngOnInit() {
    this._getSendData() 
    this._getReceiveData() 
  }

  _getSendData() {

    this.api.get('sendtransactions/'+ JSON.parse(localStorage.getItem('blockchain')).useremail).then((response: any) => {
    this.sendTransactions = response;
    console.log(response)

    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while searching for contacts");
    });
  }



  _getReceiveData() {

    this.api.get('receivetransactions/'+ JSON.parse(localStorage.getItem('blockchain')).useremail).then((response: any) => {
    this.receiveTransactions = response;
    console.log(response)

    }, () => {
      this.toastrService.success("Failed!', 'Something went wrong while searching for contacts");
    });
  }


}
