import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ForgetComponent } from './pages/forget/forget.component';
import { RegisterAsComponent } from './pages/register-as/register-as.component';
import { RegisterUserComponent } from './pages/register-user/register-user.component';
import { RegisterCompanyComponent } from './pages/register-company/register-company.component';
import { UserProfileComponent } from './pages/user-profile/user-profile.component';
import { EditUserProfileComponent } from './pages/edit-user-profile/edit-user-profile.component';
import { CompanyProfileComponent } from './pages/company-profile/company-profile.component';
import { EditCompanyProfileComponent } from './pages/edit-company-profile/edit-company-profile.component';
import { JobManagementComponent } from './pages/job-management/job-management.component';
import { PrivacyPolicyComponent } from './pages/privacy-policy/privacy-policy.component';
import { TermsAndConditionComponent } from './pages/terms-and-condition/terms-and-condition.component';
import { PayNowComponent } from './pages/pay-now/pay-now.component';
import { JobSearchAllComponent } from './pages/job-search-all/job-search-all.component';
import { ContactsComponent } from './pages/contacts/contacts.component';
import { TransactionsComponent } from './pages/transactions/transactions.component';

import { AboutComponent } from './pages/about/about.component';
import { FaqComponent } from './pages/faq/faq.component';
import { ContactUsComponent } from './pages/contact-us/contact-us.component';
import { ServicesComponent } from './pages/services/services.component';

const routes: Routes = [
  {
    path: '',
    component : HomeComponent
  },
  {
    path: 'forget_password',
    component : ForgetComponent
  },
  {
    path: 'login',
    component : LoginComponent
  },
  {
    path: 'register_as',
    component : RegisterAsComponent
  },
  {
    path: 'register_user',
    component : RegisterUserComponent
  },
  {
    path: 'register_company',
    component : RegisterCompanyComponent
  },
  {
    path: 'user_profile',
    component : UserProfileComponent
  },
  {
    path: 'edit_user_profile',
    component : EditUserProfileComponent
  },
  {
    path: 'company_profile',
    component : CompanyProfileComponent
  },
  {
    path: 'edit_company_profile',
    component : EditCompanyProfileComponent
  },
  {
    path: 'job_management',
    component : JobManagementComponent
  },
  {
    path: 'privacy_policy',
    component : PrivacyPolicyComponent
  },
  {
    path: 'terms_and_condition',
    component : TermsAndConditionComponent
  },
  {
    path: 'paynow/:userEmail',
    component : PayNowComponent
  },
  {
    path: 'recent_jobs',
    component : JobSearchAllComponent
  },
  {
    path: 'about',
    component : AboutComponent
  },
  {
    path: 'faq',
    component : FaqComponent
  },
  {
    path: 'contact_us',
    component : ContactUsComponent
  },
  {
    path: 'services',
    component : ServicesComponent
  },
  {
    path: 'contacts',
    component : ContactsComponent
  },
  {
    path: 'transactions',
    component : TransactionsComponent
  }
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
