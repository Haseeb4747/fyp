export const EncryptionPassword = 'theawebEncPassKey';
