export const EncryptionPassword = 'theawebEncPassKey';
