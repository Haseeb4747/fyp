export class Product {
    productName: string;
    productId: number;
    productPrice: number;
    productQuatity: number;
    singleProductPrice: number;
  }
  