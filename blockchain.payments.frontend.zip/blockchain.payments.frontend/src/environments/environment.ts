// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

// export const environment = {
//   production: false,
//   firebase : {apiKey: "AIzaSyD5_53hfUDwusfESy_WfwxcPGTjiCA4IPA",
//     authDomain: "dublin-laundry8580.firebaseapp.com",
//     databaseURL: "https://dublin-laundry8580.firebaseio.com",
//     projectId: "dublin-laundry8580",
//     storageBucket: "dublin-laundry8580.appspot.com",
//     messagingSenderId: "212083329704",
//     appId: "1:212083329704:web:402721552af7a872",
//     serverKey : "AAAAMWEmyqg:APA91bETJh59oAOpE4evbR03W8zPe8j3dePKQDCfSRpSjrAMbZioWe_lMquc1BR2Dj7WQFkz9ADfyM2o4YpZolnL3wxUdqjPZ77CF5tX7gYJI-nc8szZjMcNno5fxStul35qPS_DkeBa"
// }
// };

export const environment = {
  production: false,
  // apiURL: 'http://localhost:3300'
  apiURL: 'https://blockchain-payments.herokuapp.com'
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
