// export const environment = {
//   production: true,
//   firebase : {apiKey: "AIzaSyD5_53hfUDwusfESy_WfwxcPGTjiCA4IPA",
//     authDomain: "dublin-laundry8580.firebaseapp.com",
//     databaseURL: "https://dublin-laundry8580.firebaseio.com",
//     projectId: "dublin-laundry8580",
//     storageBucket: "dublin-laundry8580.appspot.com",
//     messagingSenderId: "212083329704",
//     appId: "1:212083329704:web:402721552af7a872",
//     serverkey: "AAAAMWEmyqg:APA91bETJh59oAOpE4evbR03W8zPe8j3dePKQDCfSRpSjrAMbZioWe_lMquc1BR2Dj7WQFkz9ADfyM2o4YpZolnL3wxUdqjPZ77CF5tX7gYJI-nc8szZjMcNno5fxStul35qPS_DkeBa"
// }
// };

export const environment = {
  production: true,
  // apiURL: 'http://localhost:3300'
  apiURL: 'https://hr-agency-suite.herokuapp.com'
};